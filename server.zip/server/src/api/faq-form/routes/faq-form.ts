/**
 * faq-form router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::faq-form.faq-form');
